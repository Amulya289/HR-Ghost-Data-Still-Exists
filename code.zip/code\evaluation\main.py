"""Deterministic output-contract and public-sample evaluator.

Run from the repository root with ``python code/evaluation/main.py``.
This evaluator reads only participant-facing inputs and references.
"""
from __future__ import annotations

import csv
import importlib.util
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATASET = ROOT / "dataset"
OUTPUT = ROOT / "output.csv"
EXPECTED_HEADER = ["case_id", "deletion_status", "steps_json"]
PHASE_ORDER = {"FINDING": 0, "REMEDIATION": 1, "VERIFICATION": 2}
OPERATION_ORDER = {
    "REPORT_REMAINING_RECORD": 0,
    "REPORT_EXPOSED_PII": 1,
    "REPORT_ACTIVE_DATA_FLOW": 2,
    "REPORT_RESTORE_RISK": 3,
    "DISABLE_DATA_FLOW": 0,
    "BLOCK_RESTORE": 1,
    "DELETE_RECORD": 2,
    "REDACT_RECORD": 3,
    "ANONYMIZE_RECORD": 4,
    "VERIFY_RECORD_ABSENT": 0,
    "VERIFY_RECORD_PRESENT": 1,
    "VERIFY_RECORD_REDACTED": 2,
    "VERIFY_RECORD_ANONYMIZED": 3,
    "VERIFY_DATA_FLOW_DISABLED": 4,
    "VERIFY_RESTORE_BLOCKED": 5,
}
VALID_STEPS = {
    ("FINDING", "REPORT_REMAINING_RECORD", "PRESENT"),
    ("FINDING", "REPORT_EXPOSED_PII", "PRESENT"),
    ("FINDING", "REPORT_ACTIVE_DATA_FLOW", "ACTIVE"),
    ("FINDING", "REPORT_RESTORE_RISK", "ACTIVE"),
    ("REMEDIATION", "DISABLE_DATA_FLOW", "DISABLED"),
    ("REMEDIATION", "BLOCK_RESTORE", "BLOCKED"),
    ("REMEDIATION", "DELETE_RECORD", "ABSENT"),
    ("REMEDIATION", "REDACT_RECORD", "REDACTED"),
    ("REMEDIATION", "ANONYMIZE_RECORD", "ANONYMIZED"),
    ("VERIFICATION", "VERIFY_RECORD_ABSENT", "ABSENT"),
    ("VERIFICATION", "VERIFY_RECORD_PRESENT", "PRESENT"),
    ("VERIFICATION", "VERIFY_RECORD_REDACTED", "REDACTED"),
    ("VERIFICATION", "VERIFY_RECORD_ANONYMIZED", "ANONYMIZED"),
    ("VERIFICATION", "VERIFY_DATA_FLOW_DISABLED", "DISABLED"),
    ("VERIFICATION", "VERIFY_RESTORE_BLOCKED", "BLOCKED"),
}
STEP_FIELDS = {
    "step_no", "phase", "system_id", "resource_id", "operation", "state", "evidence_id"
}


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def evidence_references() -> set[str]:
    refs = {row["file_id"] for row in load_csv(DATASET / "evidence_files.csv")}
    refs.update(row["activity_id"] for row in load_csv(DATASET / "system_activity.csv"))
    for row in load_csv(DATASET / "user_audit_log.csv"):
        if row.get("audit_id"):
            refs.add(row["audit_id"])
    return refs


def validate_inputs_and_media() -> list[str]:
    failures: list[str] = []
    required_csvs = (
        "deletion_requests.csv",
        "sample_deletion_requests.csv",
        "sample_output.csv",
        "user_identities.csv",
        "user_audit_log.csv",
        "system_activity.csv",
        "deletion_rules.csv",
        "evidence_files.csv",
    )
    for filename in required_csvs:
        path = DATASET / filename
        try:
            load_csv(path)
        except Exception as exc:
            failures.append(f"Cannot load dataset/{filename}: {exc}")
    manifest_path = DATASET / "evidence_files.csv"
    if manifest_path.exists():
        for row in load_csv(manifest_path):
            evidence_path = DATASET / row["file_path"]
            if not evidence_path.is_file():
                failures.append(f"Manifest media file is missing: {row['file_path']}")
    return failures


def validate_full_output() -> tuple[int, list[str]]:
    requests = load_csv(DATASET / "deletion_requests.csv")
    failures: list[str] = []
    if not OUTPUT.exists():
        return 0, ["Missing root output.csv"]
    with OUTPUT.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != EXPECTED_HEADER:
            failures.append(f"Header mismatch: {reader.fieldnames!r}")
        rows = list(reader)
    expected_ids = sorted(row["case_id"] for row in requests)
    actual_ids = [row.get("case_id", "") for row in rows]
    if actual_ids != expected_ids:
        failures.append("Rows/case IDs are not an exact sorted match for deletion_requests.csv")
    if len(rows) != len(requests):
        failures.append(f"Expected {len(requests)} output rows; got {len(rows)}")

    evidence_ids = evidence_references()
    for row in rows:
        case_id = row.get("case_id", "<missing case_id>")
        status = row.get("deletion_status", "")
        if status not in {"COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"}:
            failures.append(f"{case_id}: invalid deletion_status {status!r}")
        try:
            steps = json.loads(row.get("steps_json", ""))
        except json.JSONDecodeError as exc:
            failures.append(f"{case_id}: invalid steps_json ({exc})")
            continue
        if not isinstance(steps, list):
            failures.append(f"{case_id}: steps_json is not an array")
            continue
        if status == "NOT_APPLICABLE":
            if steps:
                failures.append(f"{case_id}: NOT_APPLICABLE must use []")
            continue
        if not steps:
            if status == "INCOMPLETE":
                failures.append(f"{case_id}: INCOMPLETE request has unresolved evidence and no safe plan")
                continue
            failures.append(f"{case_id}: applicable request has an empty plan")
            continue

        sort_keys: list[tuple[int, int, str, str]] = []
        for index, step in enumerate(steps, start=1):
            if not isinstance(step, dict) or set(step) != STEP_FIELDS:
                failures.append(f"{case_id}: step {index} has wrong object shape")
                continue
            if step["step_no"] != index:
                failures.append(f"{case_id}: step number at position {index} is {step['step_no']!r}")
            triple = (step["phase"], step["operation"], step["state"])
            if triple not in VALID_STEPS:
                failures.append(f"{case_id}: invalid phase/operation/state {triple!r}")
                continue
            sort_keys.append((PHASE_ORDER[step["phase"]], OPERATION_ORDER[step["operation"]],
                              step["system_id"], step["resource_id"]))
            evidence_id = step["evidence_id"]
            if step["phase"] == "FINDING" or (status == "COMPLETE" and step["phase"] == "VERIFICATION"):
                if not evidence_id:
                    failures.append(f"{case_id}: evidence citation required for {step['phase']}")
                else:
                    citations = evidence_id.split("|")
                    if any(citation not in evidence_ids for citation in citations):
                        failures.append(f"{case_id}: unknown evidence reference in {evidence_id!r}")
            elif status == "INCOMPLETE" and evidence_id:
                failures.append(f"{case_id}: planned incomplete step must have empty evidence_id")
        if sort_keys != sorted(sort_keys):
            failures.append(f"{case_id}: steps are not in required phase/operation/system/resource order")
        if status == "COMPLETE" and any(step.get("phase") != "VERIFICATION" for step in steps):
            failures.append(f"{case_id}: COMPLETE may contain only verification steps")
        if status == "INCOMPLETE":
            if not any(step.get("phase") == "FINDING" for step in steps):
                failures.append(f"{case_id}: INCOMPLETE plan has no finding")
            if not any(step.get("phase") == "REMEDIATION" for step in steps):
                failures.append(f"{case_id}: INCOMPLETE plan has no remediation")
            if not any(step.get("phase") == "VERIFICATION" for step in steps):
                failures.append(f"{case_id}: INCOMPLETE plan has no verification")
            if any(step.get("resource_id") == "unresolved_resource" for step in steps):
                failures.append(f"{case_id}: INCOMPLETE plan uses an unresolved placeholder resource")
    return len(rows), failures


def evaluate_public_sample() -> tuple[dict[str, int], list[str]]:
    """Run sample predictions in a temp path and compare to the supplied fixture."""
    source = ROOT / "code" / "main.py"
    spec = importlib.util.spec_from_file_location("audit_pipeline_for_evaluation", source)
    if spec is None or spec.loader is None:
        return {}, ["Cannot load code/main.py"]
    pipeline = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pipeline)
    expected = {row["case_id"]: row for row in load_csv(DATASET / "sample_output.csv")}
    with tempfile.TemporaryDirectory(prefix="deletion-audit-eval-") as temporary:
        pipeline.OUTPUT = Path(temporary) / "sample_output.csv"
        previous_argv = sys.argv[:]
        try:
            sys.argv = [str(source), "--sample"]
            pipeline.main()
        finally:
            sys.argv = previous_argv
        actual = {row["case_id"]: row for row in load_csv(pipeline.OUTPUT)}

    status_correct = 0
    exact_rows = 0
    exact_sequences = 0
    exact_steps = 0
    expected_steps_count = 0
    correct_fields = 0
    total_fields = 0
    failures: list[str] = []
    for case_id, expected_row in expected.items():
        actual_row = actual.get(case_id)
        if actual_row is None:
            failures.append(f"Sample request {case_id} missing from generated output")
            continue
        status_match = actual_row["deletion_status"] == expected_row["deletion_status"]
        status_correct += status_match
        expected_steps = json.loads(expected_row["steps_json"])
        actual_steps = json.loads(actual_row["steps_json"])
        sequence_match = actual_steps == expected_steps
        exact_sequences += sequence_match
        exact_rows += status_match and sequence_match
        expected_steps_count += len(expected_steps)
        for index, expected_step in enumerate(expected_steps):
            actual_step = actual_steps[index] if index < len(actual_steps) else {}
            exact_steps += actual_step == expected_step
            total_fields += len(STEP_FIELDS)
            correct_fields += sum(actual_step.get(field) == expected_step.get(field) for field in STEP_FIELDS)
        if not status_match:
            failures.append(f"{case_id}: status mismatch")
        if not sequence_match:
            failures.append(f"{case_id}: step sequence mismatch")
    metrics = {
        "sample_cases": len(expected),
        "status_correct": status_correct,
        "exact_rows": exact_rows,
        "exact_sequences": exact_sequences,
        "exact_steps": exact_steps,
        "expected_steps": expected_steps_count,
        "correct_fields": correct_fields,
        "total_fields": total_fields,
    }
    return metrics, failures


def run_custom_regressions() -> None:
    test_file = ROOT / "code" / "sample_test.py"
    spec = importlib.util.spec_from_file_location("custom_audit_regressions", test_file)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load code/sample_test.py")
    tests = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tests)
    tests.run_custom_cases()


def main() -> int:
    input_failures = validate_inputs_and_media()
    rows, contract_failures = validate_full_output()
    contract_failures[:0] = input_failures
    manifest = load_csv(DATASET / "evidence_files.csv")
    print(f"Participant inputs: CSV files loaded; manifest media files={len(manifest)}")
    print(f"Full output contract: {rows} rows; {len(contract_failures)} violations")
    for failure in contract_failures[:40]:
        print(f"ERROR: {failure}")
    if len(contract_failures) > 40:
        print(f"... {len(contract_failures) - 40} additional violations")

    metrics, sample_failures = evaluate_public_sample()
    if metrics:
        cases = metrics["sample_cases"] or 1
        steps = metrics["expected_steps"] or 1
        fields = metrics["total_fields"] or 1
        print(f"Sample status accuracy: {metrics['status_correct']}/{cases} ({metrics['status_correct']/cases:.2%})")
        print(f"Exact rows/sequences: {metrics['exact_rows']}/{cases}; {metrics['exact_sequences']}/{cases}")
        print(f"Exact steps: {metrics['exact_steps']}/{steps} ({metrics['exact_steps']/steps:.2%})")
        print(f"Field accuracy: {metrics['correct_fields']}/{fields} ({metrics['correct_fields']/fields:.2%})")
    try:
        run_custom_regressions()
    except Exception as exc:
        contract_failures.append(f"Custom regression failure: {exc}")

    for failure in sample_failures[:40]:
        print(f"SAMPLE MISMATCH: {failure}")
    if contract_failures or sample_failures:
        print("EVALUATION FAILED; review errors above before submission.")
        return 1
    print("EVALUATION PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
