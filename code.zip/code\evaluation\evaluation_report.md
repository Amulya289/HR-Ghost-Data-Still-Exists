# Evaluation Report

## Scope and method

Evaluation uses only the public participant-facing `dataset/sample_output.csv` as a reference. The sample runner compares all 32 sample requests by `case_id`, exact status, and exact ordered `steps_json` values. Per-field accuracy compares each expected step position and its seven required fields; a missing predicted step contributes seven incorrect values. Sequence accuracy requires exact equality of the ordered step arrays. No organizer-only files or hidden labels were used.

## Public sample results (current run)

| Metric | Result |
|---|---:|
| Case-level deletion-status accuracy | 23 / 32 (71.88%) |
| Exact output-row accuracy (status and full step array) | 2 / 32 (6.25%) |
| Exact ordered sequence accuracy | 2 / 32 (6.25%) |
| Exact expected steps at the same array position | 58 / 193 (30.05%) |
| Step-field accuracy | 714 / 1,351 (52.85%) |

These results **do not meet the public sample reference**. The latest full output has 518 sorted rows with the exact CSV header and valid step serialization. The evaluator still reports **12 unresolved-evidence cases** with no safe, evidence-backed plan, and intentionally exits unsuccessfully. Do not submit it as a passing result. No reference answers are available here for scoring the remaining 486 requests.

## Participant-created regression cases

The three custom checks are implemented in `code/sample_test.py` and passed in the recorded run, as also reported by the evaluation command:

1. **Marketing-only opt-out is not deletion:** a request to remove marketing contact while retaining the account must not authorize account deletion.
2. **Identifier matching is token-exact:** `user_43` matches itself but must not match `user_430`.
3. **Historical identifiers respect `audit_at`:** an email alias change before the cutoff resolves to the user; the same change after the cutoff does not.

## Failures found and improvements made

- Repaired malformed source blocks and added a single `--sample`/full-data generation path.
- Added evidence parsing caches, nested JSON decoding for SQL exports, row-level SQL timestamp filtering, PDF text extraction, and optional screenshot OCR support.
- Loaded the supplied deletion policy and applied category actions to record decisions.
- Replaced broad support-message keyword decisions with checks for identifiers in message/requester fields; retained messages can be verified redacted without inventing a deletion finding.
- Replaced non-contract states such as `UNKNOWN`, `PLANNED`, and `PENDING` with allowed step states and added row, phase, field, operation, and state validation.
- Added exact comparison of public sample answers and three semantic regression cases.
- Added an automated full-output and sample evaluation entry point at `code/evaluation/main.py`; it returns non-zero on contract violations or public sample mismatches.
- Added subject-linked parsing for pipe-delimited text evidence and structured JSON log records, with per-record cutoff checks and interpretation of explicit state fields.
- Removed fabricated `unresolved_resource` findings and citations when the supplied evidence cannot establish a resource, leaving these requests explicitly unresolved for the evaluator instead of asserting unsupported data.

## Outstanding limitations

The current detector cannot reliably link every request to a resource using the supplied evidence. Twelve full-dataset requests have no safely attributable records or activity and therefore lack a valid incomplete-case remediation plan. The implementation deliberately does not use sample case numbering or expected outputs as predictions. As a result, sample completion statuses and many step arrays remain mismatched. The full-dataset output should be reviewed as a baseline, not presented as fully accurate.

Screenshot OCR requires the external Tesseract executable in addition to the Python packages in `code/requirements.txt`. It was not installed in the validation environment, so screenshot evidence was not OCR-searched in the recorded evaluation. Scanned PDFs likewise may have no extractable text. The evaluation workflow reports this missing OCR coverage and exits unsuccessfully when output or public-sample checks fail.
