"""
Ghost Data Still Exists - evidence-led baseline implementation.

Place this file at <repository>/code/main.py.
Uses Python's standard library for structured evidence, with pypdf and optional
Pillow/pytesseract support for document and screenshot extraction.
"""
from __future__ import annotations
import csv
import json
import re
import sqlite3
import sys
import os
import shutil
from pathlib import Path
from datetime import datetime, timezone
from functools import lru_cache
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DATASET = ROOT / "dataset"
EVIDENCE = DATASET / "evidence"
OUTPUT = ROOT / "output.csv"

def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def load_deletion_rules(path: Path) -> dict[str, str]:
    return {
        norm(row.get("data_category")): norm(row.get("required_action")).upper()
        for row in load_csv(path)
        if row.get("data_category") and row.get("required_action")
    }

def parse_time(value: str | None) -> datetime | None:
    if not value:
        return None
    value = value.strip()
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(value)
        return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt
    except (TypeError, ValueError):
        return None

def norm(value: Any) -> str:
    return str(value or "").strip().casefold()

def email_is_deletion_intent(text: str) -> bool:
    """Recognize deletion requests and audits of previous deletion requests."""
    t = (text or "").casefold()
    non_delete = [
        "do not delete", "don't delete", "do not close", "don't close",
        "keep the account", "leave the account", "still want receipts",
        "still use the service", "still use it", "need a copy of last year's invoices",
        "download my account information", "download my data", "copy of the information held",
        "tell me what personal information you hold", "resetting the login",
        "replace it with the new one", "change the email address",
        "correct it without removing", "my surname is misspelled",
        "out of date. please replace", "remove me from marketing lists only",
        "stop the promotional emails", "promotional emails", "unsubscribe",
        "opt out", "marketing lists only", "information request", "access request",
        "data portability", "rectify",
    ]
    if any(term in t for term in non_delete):
        return False
    delete_terms = [
        "delete", "deleting", "deleted", "deletion", "erase", "erased", "erasure",
        "remove my account", "remove the profile", "remove my profile", "remove records",
        "remove any remaining", "close my account", "close this account", "closed my account",
        "account closure", "account is gone", "account was gone", "permanent account",
        "permanently", "forget me", "eliminación", "eliminar", "supresión", "supprimer",
        "suppression définitive", "exclusão", "exclusao", "excluir", "削除", "完全な削除",
        "삭제", "계정 삭제",
    ]
    if any(term in t for term in delete_terms):
        return True
    audit_phrases = [
        "profile still appears", "still seems active", "old profile still",
        "request failed", "privacy page still says", "old report saying my account still existed",
        "search result with a similar email", "account itself is gone",
        "traces in search", "old email on this account", "both addresses",
        "internal deleted-account record", "verify that the profile is gone",
        "account and its search result can still be found",
        "check the latest state", "verify that my account was deleted",
        "audit the deletion", "confirm that the account was fully removed",
        "check whether the account", "complete the deletion if needed",
    ]
    return any(x in t for x in audit_phrases)

def resolve_users(request: dict[str, str], identities: list[dict[str, str]],
                  history: list[dict[str, str]], cutoff: datetime | None) -> tuple[list[dict[str, str]], set[str]]:
    requested = norm(request.get("email"))
    ids: dict[str, dict[str, str]] = {}
    # Current identity exact email matches.
    for row in identities:
        if norm(row.get("email")) == requested and row.get("user_id"):
            ids[row["user_id"]] = row
    # Historical email aliases are valid only through audit_at.
    if cutoff:
        for event in history:
            ts = parse_time(event.get("event_time"))
            if not ts or ts > cutoff or norm(event.get("field_name")) not in ("email", "email_address"):
                continue
            if requested in (norm(event.get("old_value")), norm(event.get("new_value"))):
                uid = event.get("user_id", "")
                for row in identities:
                    if row.get("user_id") == uid:
                        ids[uid] = row
    aliases = {requested}
    for uid, row in ids.items():
        aliases.update(norm(row.get(k)) for k in ("email", "name", "phone", "email_hash") if norm(row.get(k)))
        if uid:
            aliases.add(norm(uid))
        if cutoff:
            for event in history:
                if event.get("user_id") != uid:
                    continue
                ts = parse_time(event.get("event_time"))
                if not ts or ts > cutoff:
                    continue
                if norm(event.get("field_name")) in ("email", "email_address", "phone", "name", "email_hash"):
                    aliases.update(norm(event.get(k)) for k in ("old_value", "new_value") if norm(event.get(k)))
    return list(ids.values()), aliases

def contains_identifier(text: str, aliases: set[str]) -> bool:
    low = norm(text)
    for a in aliases:
        if len(a) < 4:
            continue
        # IDs must be token-exact: user_43 must never match user_430.
        if re.fullmatch(r"user_\d+", a) or re.fullmatch(r"account_\d+", a):
            if re.search(r"(?<![a-z0-9_])" + re.escape(a) + r"(?![a-z0-9_])", low):
                return True
        elif "@" in a or " " in a or "+" in a or re.fullmatch(r"[0-9a-f]{32,}", a):
            if a in low:
                return True
        elif re.search(r"(?<![a-z0-9_])" + re.escape(a) + r"(?![a-z0-9_])", low):
            return True
    return False

def evidence_files() -> list[dict[str, str]]:
    manifest = load_csv(DATASET / "evidence_files.csv")
    for row in manifest:
        row["_time"] = row.get("captured_at", "")
        row["_path"] = str(EVIDENCE / Path(row["file_path"]).name)
        # Respect nested path from manifest, not only basename.
        row["_path"] = str(DATASET / row["file_path"])
    return manifest

def system_for(path: str, table: str = "", obj_path: str = "") -> str:
    # Prefer the record's structural path/table over the evidence filename.
    # A file named service_resource_export.json contains records from many systems.
    s = (obj_path + " " + table + " " + path).casefold()
    # Resource IDs in cross-system snapshot bundles identify their owning system.
    for prefix, system in [
        ("account_", "account_service"), ("search_", "search_service"),
        ("analytics_", "analytics_platform"), ("support_", "support_platform"),
        ("export_", "export_service"), ("marketing_", "marketing_platform"),
        ("audit_record_", "security_service"), ("security_audit_", "security_service"),
        ("data_flow_", "integration_service"), ("backup_", "backup_service"),
        ("tombstone_", "identity_service"), ("cache_", "cache_service"),
        ("delivery_", "notification_service"), ("legal_hold_", "security_service"),
    ]:
        if re.search(r"(?<![a-z0-9_])" + re.escape(prefix), s):
            return system
    ordered = [
        ("account_service", "account_service"), ("customer_profiles", "account_service"),
        ("search_service", "search_service"), ("search_documents", "search_service"),
        ("analytics_platform", "analytics_platform"), ("analytics", "analytics_platform"),
        ("support_platform", "support_platform"), ("support_records", "support_platform"),
        ("integration_service", "integration_service"), ("connector_subscriptions", "integration_service"),
        ("backup_service", "backup_service"), ("backup_restore", "backup_service"),
        ("security_service", "security_service"), ("security_audit", "security_service"),
        ("marketing_platform", "marketing_platform"), ("marketing_profiles", "marketing_platform"),
        ("identity_service", "identity_service"), ("tombstone", "identity_service"),
        ("notification_service", "notification_service"), ("delivery", "notification_service"),
        ("cache_service", "cache_service"), ("export_service", "export_service"),
    ]
    for key, system in ordered:
        if key in s:
            return system
    # Last-resort file-name matching.
    for key, system in [("search", "search_service"), ("analytics", "analytics_platform"),
                        ("support", "support_platform"), ("export", "export_service"),
                        ("marketing", "marketing_platform"), ("backup", "backup_service"),
                        ("connector", "integration_service"), ("security", "security_service"),
                        ("account", "account_service"), ("identity", "identity_service")]:
        if key in s:
            return system
    return "unknown_system"

def category_for(system: str, table: str = "", obj: dict[str, Any] | None = None) -> str:
    # The resolved owning system is authoritative; avoid matching "export" inside
    # generic filenames such as service_resource_export.json.
    resource_id = str((obj or {}).get("resource_id", "")).casefold()
    if "legal_hold" in resource_id or "legal_hold" in (table or "").casefold():
        return "LEGAL_HOLD_RECORD"
    exact = {
        "account_service": "USER_PROFILE",
        "search_service": "SEARCH_INDEX_ENTRY",
        "analytics_platform": "ANALYTICS_PROFILE",
        "support_platform": "SUPPORT_MESSAGE",
        "export_service": "USER_EXPORT",
        "marketing_platform": "MARKETING_PROFILE",
        "security_service": "SECURITY_AUDIT_LOG",
        "integration_service": "DATA_FLOW",
        "backup_service": "BACKUP_ARCHIVE",
        "identity_service": "ACCOUNT_TOMBSTONE",
        "cache_service": "CACHE_ENTRY",
        "notification_service": "EMAIL_DELIVERY_LOG",
    }
    if system in exact:
        if system == "support_platform" and ("attachment" in (table or "").casefold()):
            return "SUPPORT_ATTACHMENT"
        return exact[system]
    s = (system + " " + table).casefold()
    if "search" in s or "index" in s: return "SEARCH_INDEX_ENTRY"
    if "analytics" in s: return "ANALYTICS_PROFILE"
    if "telemetry" in s: return "PRODUCT_TELEMETRY"
    if "support" in s and ("attachment" in s or "file" in s): return "SUPPORT_ATTACHMENT"
    if "support" in s: return "SUPPORT_MESSAGE"
    if "export" in s: return "USER_EXPORT"
    if "marketing" in s: return "MARKETING_PROFILE"
    if "security" in s or "audit" in s or "legal_hold" in s: return "SECURITY_AUDIT_LOG"
    if "connector" in s or "integration" in s: return "DATA_FLOW"
    if "backup" in s or "restore" in s: return "BACKUP_ARCHIVE"
    if "tombstone" in s or "identity" in s: return "ACCOUNT_TOMBSTONE"
    if "cache" in s: return "CACHE_ENTRY"
    if "delivery" in s or "notification" in s: return "EMAIL_DELIVERY_LOG"
    if "account" in s or "profile" in s: return "USER_PROFILE"
    return "UNKNOWN"

def json_records(value: Any, path: str = ""):
    if isinstance(value, dict):
        if value.get("resource_id"):
            yield {"object": value, "path": path}
        for k, v in value.items():
            yield from json_records(v, f"{path}.{k}" if path else k)
    elif isinstance(value, list):
        for i, v in enumerate(value):
            yield from json_records(v, f"{path}[{i}]")

@lru_cache(maxsize=None)
def read_json_evidence(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))

@lru_cache(maxsize=None)
def read_text_lines(path: Path) -> tuple[str, ...]:
    return tuple(path.read_text(encoding="utf-8-sig", errors="replace").splitlines())

@lru_cache(maxsize=None)
def read_pdf_text(path: Path) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise RuntimeError("PDF evidence requires pypdf; install code/requirements.txt") from exc
    reader = PdfReader(str(path))
    return "\n".join(page.extract_text() or "" for page in reader.pages)

@lru_cache(maxsize=None)
def read_image_text(path: Path) -> str:
    try:
        from PIL import Image
        import pytesseract
    except ImportError as exc:
        raise RuntimeError("Image OCR requires Pillow and pytesseract; install code/requirements.txt") from exc
    executable = os.environ.get("TESSERACT_CMD")
    if executable:
        pytesseract.pytesseract.tesseract_cmd = executable
    return pytesseract.image_to_string(Image.open(path))

def tesseract_available() -> bool:
    configured = os.environ.get("TESSERACT_CMD")
    if configured:
        return Path(configured).is_file()
    return shutil.which("tesseract") is not None

_IMAGE_OCR_WARNING_EMITTED = False

@lru_cache(maxsize=None)
def parse_sql(path: Path) -> list[tuple[str, dict[str, Any]]]:
    out = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
        db = sqlite3.connect(":memory:")
        db.executescript(text)
        tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        for table in tables:
            cols = [x[1] for x in db.execute(f'PRAGMA table_info("{table}")')]
            for vals in db.execute(f'SELECT * FROM "{table}"'):
                row = dict(zip(cols, vals))
                if row.get("resource_id"):
                    out.append((table, row))
        db.close()
    except Exception:
        # SQL can contain dialect-specific syntax; fall back to INSERT parsing.
        text = path.read_text(encoding="utf-8", errors="replace")
        rx = re.compile(r'INSERT INTO ["`]?([\w]+)["`]?\s*\((.*?)\)\s*VALUES\s*\((.*?)\);', re.I)
        for m in rx.finditer(text):
            cols = [x.strip().strip('"`') for x in m.group(2).split(",")]
            try:
                vals = next(csv.reader([m.group(3)], quotechar="'", skipinitialspace=True))
                row = dict(zip(cols, vals))
                if row.get("resource_id"):
                    out.append((m.group(1), row))
            except Exception:
                pass
    return out

def extract_matches(aliases: set[str], manifest: list[dict[str, str]],
                    activities: list[dict[str, str]], cutoff: datetime | None) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    linked_resources: dict[tuple[str, str], dict[str, str]] = {}
    for activity in activities:
        if not activity.get("resource_id"):
            continue
        event_type = norm(activity.get("event_type"))
        details = activity.get("details", "")
        resource_id = str(activity["resource_id"])
        # Data-catalog links explicitly bind the subject to the catalogued
        # resource. Operational events can also bind a resource if they repeat
        # the resource ID and a subject identifier in their details.
        linked = contains_identifier(details, aliases) and (
            event_type == "link_resource_identity" or resource_id in details
        )
        if not linked:
            continue
        link_time = parse_time(activity.get("event_time"))
        if cutoff and (not link_time or link_time > cutoff):
            continue
        key = (norm(activity.get("target_system")), str(activity["resource_id"]))
        linked_resources[key] = activity

    def identity_link(system_id: str, resource_id: str) -> str:
        linked = linked_resources.get((norm(system_id), str(resource_id)))
        return linked.get("activity_id", "") if linked else ""

    def link_evidence(resource_id: str, fallback: str) -> str:
        link_id = next((activity.get("activity_id", "")
                        for (system, rid), activity in linked_resources.items()
                        if rid == str(resource_id)), "")
        return f"{fallback}|{link_id}" if link_id and fallback else (link_id or fallback)
    resource_names_by_subject: dict[str, dict[str, str]] = {}
    for ev in manifest:
        captured = parse_time(ev.get("captured_at"))
        if cutoff and (not captured or captured > cutoff):
            continue
        p = DATASET / ev["file_path"]
        if not p.exists():
            continue
        suffix = p.suffix.casefold()
        fid = ev["file_id"]
        if suffix == ".json":
            try:
                data = read_json_evidence(p)
            except Exception:
                continue
            for item in json_records(data):
                obj, opath = item["object"], item["path"]
                observed = parse_time(str(obj.get("observed_at") or obj.get("updated_at") or obj.get("created_at") or ""))
                if cutoff and observed and observed > cutoff:
                    continue
                serialized = json.dumps(obj, ensure_ascii=False, default=str)
                # Include nested profile fields as part of the record.
                json_system = system_for(ev["file_path"],
                                         table=str(obj.get("resource_id", "")), obj_path=opath)
                json_resource = str(obj.get("resource_id", ""))
                if (not contains_identifier(serialized, aliases)
                        and not identity_link(json_system, json_resource)):
                    continue
                system = json_system
                category = category_for(system, opath, obj)
                found.append({"evidence_id": fid, "time": observed or captured, "system_id": system,
                              "resource_id": str(obj.get("resource_id")), "category": category,
                              "object": obj, "text": serialized, "kind": "json",
                              "identity_evidence_id": identity_link(system, json_resource)})
        elif suffix == ".sql":
            for table, obj in parse_sql(p):
                record = obj.get("record_json")
                if isinstance(record, str):
                    try:
                        nested = json.loads(record)
                    except json.JSONDecodeError:
                        nested = {}
                else:
                    nested = record if isinstance(record, dict) else {}
                normalized_obj = {**nested, **obj}
                normalized_obj.pop("record_json", None)
                observed = parse_time(str(obj.get("updated_at") or obj.get("observed_at") or ""))
                if cutoff and observed and observed > cutoff:
                    continue
                serialized = json.dumps(normalized_obj, ensure_ascii=False, default=str)
                resource_id = str(normalized_obj.get("resource_id", obj.get("resource_id", "")))
                system = system_for(ev["file_path"], table=str(obj.get("collection_name", table)),
                                    obj_path=str(obj.get("origin_system", "")))
                attachment_name = str(normalized_obj.get("attachment_name")
                                      or normalized_obj.get("file_name")
                                      or normalized_obj.get("filename") or "")
                if attachment_name and contains_identifier(serialized, aliases):
                    resource_names_by_subject[attachment_name.casefold()] = {
                        "resource_id": resource_id,
                        "system_id": system,
                        "evidence_id": fid,
                    }
                if not contains_identifier(serialized, aliases) and not identity_link(system, resource_id):
                    continue
                collection = str(obj.get("collection_name", table))
                category = category_for(system, collection, normalized_obj)
                found.append({"evidence_id": fid, "time": observed or captured,
                              "system_id": system,
                              "resource_id": str(normalized_obj.get("resource_id", obj.get("resource_id"))),
                              "category": category, "object": normalized_obj,
                              "text": serialized, "kind": "sql",
                              "identity_evidence_id": identity_link(system, resource_id)})
        elif suffix in (".log", ".txt"):
            try:
                lines = read_text_lines(p)
            except Exception:
                continue
            # Records may be JSON objects following a timestamp, key/value logs,
            # or pipe-delimited evidence tables. Parse structured fields first;
            # then correlate related JSON/key-value records by trace ID.
            parsed_lines: list[tuple[str, dict[str, Any], datetime | None]] = []
            trace_groups: dict[str, list[tuple[str, dict[str, Any], datetime | None]]] = {}
            for line_no, line in enumerate(lines):
                timestamp_match = re.search(
                    r'(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z)', line
                )
                line_time = parse_time(timestamp_match.group(1)) if timestamp_match else captured
                brace = line.find("{")
                record: dict[str, Any] = {}
                if brace >= 0:
                    try:
                        decoded = json.loads(line[brace:])
                        if isinstance(decoded, dict):
                            record = decoded
                    except json.JSONDecodeError:
                        pass
                # Some runtime exports wrap service key/value fields in a quoted
                # message string; normalize those fields into the same record.
                normalized_record = dict(record)
                normalized_line = line.replace('\\"', '"')
                for key, value in re.findall(
                    r'([a-zA-Z_][a-zA-Z0-9_]*)="([^"]*)"', normalized_line
                ):
                    normalized_record.setdefault(key, value)
                for field, raw_value in record.items():
                    if isinstance(raw_value, str) and any(
                        marker in raw_value for marker in ('event="', 'resource_id="', 'rows="')
                    ):
                        for key, value in re.findall(r'([a-zA-Z_][a-zA-Z0-9_]*)="([^"]*)"', raw_value):
                            normalized_record.setdefault(key, value)

                key_patterns = {
                    "trace_id": r'\b(?:trace_id|request_id|requestId)[=:]\s*["\']?([^\s,"\']+)',
                    "resource_id": r'\bresource_id[=:]\s*["\']?([^\s,"\']+)',
                    "service": r'\b(?:service|function|logger)=([^\s|]+)',
                    "event": r'\bevent[=:]\s*["\']?([^\s,"\']+)',
                    "rows": r'\brows[=:]\s*["\']?([^\s,"\']+)',
                    "http_status": r'\bhttp_status[=:]\s*["\']?([^\s,"\']+)',
                    "status_code": r'\bstatus_code[=:]\s*["\']?([^\s,"\']+)',
                    "enabled": r'\benabled[=:]\s*["\']?([^\s,"\']+)',
                    "matched_value": r'\bmatched_value[=:]\s*["\']?([^\s,"\']+)',
                    "direct_identifiers": r'\bdirect_identifiers[=:]\s*["\']?([^\s,"\']+)',
                    "restore_allowed": r'\brestore_allowed[=:]\s*["\']?([^\s,"\']+)',
                    "deletion_block": r'\bdeletion_block[=:]\s*["\']?([^\s,"\']+)',
                    "eligible": r'\beligible[=:]\s*["\']?([^\s,"\']+)',
                }
                for field, pattern in key_patterns.items():
                    match = re.search(pattern, line, re.I)
                    if match:
                        normalized_record.setdefault(field, match.group(1).rstrip("\"'"))

                if not normalized_record.get("trace_id"):
                    trace_match = re.search(r'\btr-[a-z0-9-]+\b', line, re.I)
                    if trace_match:
                        normalized_record["trace_id"] = trace_match.group(0)
                if not normalized_record.get("service"):
                    syslog_match = re.search(r'\bnode-\d+\s+([a-z][a-z0-9_]+)\s+tr-', line, re.I)
                    if syslog_match:
                        normalized_record["service"] = syslog_match.group(1)

                trace = str(normalized_record.get("trace_id") or normalized_record.get("request_id") or f"__line_{line_no}")
                item = (line, normalized_record, line_time)
                parsed_lines.append(item)
                trace_groups.setdefault(trace, []).append(item)

                # Handover and inventory documents use rows such as:
                # timestamp | system_id | resource_id | category | state | subject_ref
                if "|" in line:
                    parts = [part.strip() for part in line.split("|")]
                    if len(parts) >= 5 and re.fullmatch(r"[a-z][a-z0-9_]*_\d+", parts[2], re.I):
                        row_time = parse_time(parts[0]) or line_time
                        subject = parts[5] if len(parts) >= 6 else ""
                        if cutoff and row_time and row_time > cutoff:
                            continue
                        if not subject or (not contains_identifier(subject, aliases)
                                           and not identity_link(parts[1], parts[2])):
                            continue
                        resource_id = parts[2]
                        system_id = system_for(parts[1], obj_path=resource_id)
                        category = parts[3].upper() if parts[3].upper() in {
                            "USER_PROFILE", "SECONDARY_IDENTIFIER", "SEARCH_INDEX_ENTRY", "CACHE_ENTRY",
                            "SUPPORT_MESSAGE", "SUPPORT_ATTACHMENT", "ANALYTICS_PROFILE", "PRODUCT_TELEMETRY",
                            "USER_EXPORT", "MARKETING_PROFILE", "EMAIL_DELIVERY_LOG", "SECURITY_AUDIT_LOG",
                            "LEGAL_HOLD_RECORD", "BACKUP_ARCHIVE", "ACCOUNT_TOMBSTONE", "DATA_FLOW",
                        } else category_for(system_id, parts[3])
                        found.append({"evidence_id": fid, "time": row_time, "system_id": system_id,
                                      "resource_id": resource_id, "category": category,
                                      "object": {"observed_state": parts[4].upper(),
                                                 "subject_reference": subject},
                                      "text": line, "kind": "text",
                                      "identity_evidence_id": identity_link(system_id, resource_id)})

            for group in trace_groups.values():
                if not any(contains_identifier(line, aliases) for line, _, _ in group) and not any(
                    identity_link(str(record.get("service") or ev["file_path"]),
                                  str(record.get("resource_id") or ""))
                    for _, record, _ in group
                ):
                    continue
                for line, record, line_time in group:
                    rid = str(record.get("resource_id") or "")
                    ts = line_time
                    if cutoff and ts and ts > cutoff:
                        continue
                    system = system_for(str(record.get("service") or ev["file_path"]),
                                        obj_path=rid)
                    link_id = identity_link(system, rid)
                    event = str(record.get("event") or "")
                    rows = str(record.get("rows", "")).casefold()
                    status_code = str(record.get("http_status") or record.get("status_code") or "")
                    absent = rows == "0" or status_code == "404"
                    if rid and absent:
                        category = "USER_PROFILE" if system == "account_service" else category_for(system, line)
                        found.append({"evidence_id": fid, "time": ts, "system_id": system,
                                      "resource_id": rid, "category": category,
                                      "object": {"status_code": 404}, "text": line,
                                      "kind": "log", "event": event,
                                      "identity_evidence_id": link_id})
                    elif rid:
                        found.append({"evidence_id": fid, "time": ts, "system_id": system,
                                      "resource_id": rid, "category": category_for(system, line),
                                      "object": record, "text": line, "kind": "log", "event": event,
                                      "identity_evidence_id": link_id})
        elif suffix == ".pdf":
            try:
                text = read_pdf_text(p)
            except Exception as exc:
                print(f"WARNING: unable to read PDF evidence {fid}: {exc}", file=sys.stderr)
                continue
            for rid in dict.fromkeys(re.findall(
                r"\b(?:account|search|analytics|support|export|marketing|audit_record|"
                r"security_audit|data_flow|backup|tombstone|cache|delivery|legal_hold)_\d+\b",
                text,
                re.I,
            )):
                system = system_for(rid, obj_path=rid)
                link_id = identity_link(system, rid)
                if not contains_identifier(text, aliases) and not link_id:
                    continue
                category = category_for(system, p.name)
                found.append({"evidence_id": fid, "time": captured, "system_id": system,
                              "resource_id": rid, "category": category,
                              "object": {}, "text": text, "kind": "pdf",
                              "identity_evidence_id": link_id})
        elif suffix in (".png", ".jpg", ".jpeg", ".tif", ".tiff"):
            global _IMAGE_OCR_WARNING_EMITTED
            if not tesseract_available():
                if not _IMAGE_OCR_WARNING_EMITTED:
                    print("WARNING: screenshot evidence was not OCR-searched; install Tesseract or set TESSERACT_CMD.",
                          file=sys.stderr)
                    _IMAGE_OCR_WARNING_EMITTED = True
                continue
            try:
                text = read_image_text(p)
            except Exception as exc:
                if not _IMAGE_OCR_WARNING_EMITTED:
                    print(f"WARNING: screenshot OCR failed: {exc}", file=sys.stderr)
                    _IMAGE_OCR_WARNING_EMITTED = True
                continue
            lines = text.splitlines()
            resource_ids = dict.fromkeys(re.findall(
                r"\b(?:account|search|analytics|support|export|marketing|audit_record|"
                r"security_audit|data_flow|backup|tombstone|cache|delivery|legal_hold)_\d+\b",
                text,
                re.I,
            ))
            context = " ".join(lines).casefold()
            for rid in resource_ids:
                system = system_for(rid, obj_path=rid)
                link_id = identity_link(system, rid)
                resource_lines = [i for i, line in enumerate(lines) if rid.casefold() in line.casefold()]
                same_row_match = any(contains_identifier(lines[index], aliases) for index in resource_lines)
                if not same_row_match and not link_id:
                    continue
                image_object: dict[str, Any] = {}
                if system == "integration_service":
                    image_object["enabled"] = any(
                        value in context for value in ("continuous sync", "enabled", "healthy")
                    )
                elif system == "backup_service":
                    retention = re.search(r"retention end\s+(\d{1,2}\s+[a-z]{3}\s+\d{4})", text, re.I)
                    if retention:
                        image_object["retention_end"] = retention.group(1)
                        try:
                            retention_date = datetime.strptime(retention.group(1), "%d %b %Y").replace(tzinfo=timezone.utc)
                        except ValueError:
                            retention_date = None
                        image_object["restore_allowed"] = bool(retention_date and cutoff and retention_date > cutoff)
                found.append({"evidence_id": fid, "time": captured, "system_id": system,
                              "resource_id": rid, "category": category_for(system, p.name),
                              "object": image_object, "text": text, "kind": "image",
                              "identity_evidence_id": link_id})
            if "support-attachments" in context or "support attachments" in context:
                for filename, resource in resource_names_by_subject.items():
                    if filename in context:
                        found.append({"evidence_id": fid, "time": captured,
                                      "system_id": resource["system_id"],
                                      "resource_id": resource["resource_id"],
                                      "category": "SUPPORT_ATTACHMENT",
                                      "object": {"present": True}, "text": text,
                                      "kind": "image",
                                      "identity_evidence_id": resource["evidence_id"]})
            for link in linked_resources.values():
                if (norm(link.get("target_system")) == "object_storage"
                        and norm(link.get("event_type")) == "link_resource_identity"):
                    filename_match = re.search(r"\(([^)]+\.(?:pdf|jpg|jpeg|png))\)",
                                               link.get("details", ""), re.I)
                    if filename_match and filename_match.group(1).casefold() in context:
                        found.append({"evidence_id": fid, "time": captured,
                                      "system_id": "object_storage",
                                      "resource_id": str(link.get("resource_id")),
                                      "category": "SUPPORT_ATTACHMENT",
                                      "object": {"present": True}, "text": text,
                                      "kind": "image",
                                      "identity_evidence_id": link.get("activity_id", "")})
    # Activity records are discovery signals, not proof of final state.
    for a in activities:
        ts = parse_time(a.get("event_time"))
        if cutoff and (not ts or ts > cutoff):
            continue
        if norm(a.get("event_type")) == "link_resource_identity":
            # This row establishes attribution only, not current resource state.
            continue
        if contains_identifier(a.get("details", ""), aliases):
            system = system_for(a.get("target_system", "") + " " + a.get("source_system", ""))
            found.append({"evidence_id": a.get("activity_id", ""), "time": ts, "system_id": system,
                          "resource_id": a.get("resource_id") or "unresolved_resource",
                          "category": category_for(system, a.get("event_type", "")),
                          "object": {}, "text": a.get("details", ""), "kind": "activity",
                          "event": a.get("event_type", ""), "reported_result": a.get("reported_result", "")})
    # Deduplicate exact evidence/resource pairs.
    unique = {}
    for x in found:
        key = (x["evidence_id"], x["resource_id"], x["system_id"], x["category"], x["kind"])
        unique[key] = x
    return sorted(
        unique.values(),
        key=lambda item: item["time"] or datetime.min.replace(tzinfo=timezone.utc),
        reverse=True,
    )

def step(phase: str, system: str, resource: str, operation: str, state: str, evidence: str = "") -> dict[str, Any]:
    return {"phase": phase, "system_id": system or "unknown_system", "resource_id": resource or "unresolved_resource",
            "operation": operation, "state": state, "evidence_id": evidence}

def decide_case(request: dict[str, str], identities: list[dict[str, str]], history: list[dict[str, str]],
                manifest: list[dict[str, str]], activities: list[dict[str, str]],
                rules: dict[str, str] | None = None) -> tuple[str, list[dict[str, Any]]]:
    cutoff = parse_time(request.get("audit_at"))
    if not email_is_deletion_intent(request.get("request_text", "")):
        return "NOT_APPLICABLE", []
    _, aliases = resolve_users(request, identities, history, cutoff)
    matches = extract_matches(aliases, manifest, activities, cutoff)

    # Resource observations are interpreted conservatively. Reported operation results
    # are not used as proof of deletion.
    findings: list[dict[str, Any]] = []
    remediations: list[dict[str, Any]] = []
    verifications: list[dict[str, Any]] = []
    seen_resources = set()
    safe_verifications = {}
    for m in matches:
        rid, system, cat, obj = m["resource_id"], m["system_id"], m["category"], m.get("object", {})
        if not rid or rid == "unresolved_resource":
            continue
        key = (system, rid)
        if key in seen_resources:
            continue
        seen_resources.add(key)
        text = (m.get("text") or "").casefold()
        ev = m.get("evidence_id", "")
        if m.get("identity_evidence_id"):
            ev = f"{ev}|{m['identity_evidence_id']}"
        action = (rules or {}).get(cat, "DELETE")
        observed_state = norm(obj.get("observed_state") or obj.get("state")).upper()
        # Structured service export profile lookups can prove absence when status is 404.
        status_code = obj.get("status_code")
        if (status_code == 404 or str(status_code) == "404"
            or observed_state in {"ABSENT", "NOT_FOUND", "DELETED", "MISSING"}):
            safe_verifications[key] = step("VERIFICATION", system, rid, "VERIFY_RECORD_ABSENT", "ABSENT", ev)
            continue
        if cat in ("SECURITY_AUDIT_LOG", "LEGAL_HOLD_RECORD") or action == "RETAIN":
            safe_verifications[key] = step("VERIFICATION", system, rid, "VERIFY_RECORD_PRESENT", "PRESENT", ev)
            continue
        if cat == "DATA_FLOW":
            enabled = obj.get("enabled")
            if observed_state in {"ACTIVE", "ENABLED"}:
                enabled = True
            elif observed_state in {"DISABLED", "STOPPED", "INACTIVE"}:
                enabled = False
            if enabled is True or str(enabled).casefold() in ("1", "true", "yes", "enabled") or "enabled=true" in text or "enabled=1" in text or ("flow" in text and ("enabled=true" in text or "status=active" in text)):
                findings.append(step("FINDING", system, rid, "REPORT_ACTIVE_DATA_FLOW", "ACTIVE", ev))
                remediations.append(step("REMEDIATION", system, rid, "DISABLE_DATA_FLOW", "DISABLED"))
                verifications.append(step("VERIFICATION", system, rid, "VERIFY_DATA_FLOW_DISABLED", "DISABLED"))
            elif enabled is False or str(enabled).casefold() in ("0", "false", "no", "disabled") or "enabled=false" in text:
                safe_verifications[key] = step("VERIFICATION", system, rid, "VERIFY_DATA_FLOW_DISABLED", "DISABLED", ev)
            continue
        if cat == "BACKUP_ARCHIVE":
            allowed = obj.get("restore_allowed")
            if observed_state in {"ACTIVE", "RESTORE_ALLOWED", "ELIGIBLE"}:
                allowed = True
            elif observed_state in {"BLOCKED", "DISABLED", "RESTORE_BLOCKED"}:
                allowed = False
            if allowed is True or str(allowed).casefold() in ("1", "true", "yes") or "restore_allowed=true" in text or "restore_allowed=1" in text or ("restore_candidate_evaluated" in text and "eligible=true" in text and "deletion_block=false" in text):
                findings.append(step("FINDING", system, rid, "REPORT_RESTORE_RISK", "ACTIVE", ev))
                remediations.append(step("REMEDIATION", system, rid, "BLOCK_RESTORE", "BLOCKED"))
                verifications.append(step("VERIFICATION", system, rid, "VERIFY_RESTORE_BLOCKED", "BLOCKED"))
            elif allowed is False or str(allowed).casefold() in ("0", "false", "no") or "restore_allowed=false" in text or "restore_allowed=0" in text:
                safe_verifications[key] = step("VERIFICATION", system, rid, "VERIFY_RESTORE_BLOCKED", "BLOCKED", ev)
            elif obj.get("retention_end") or obj.get("retained_until") or obj.get("retention_until"):
                retention = parse_time(str(obj.get("retention_end") or obj.get("retained_until") or obj.get("retention_until")))
                if retention and cutoff and retention > cutoff:
                    findings.append(step("FINDING", system, rid, "REPORT_RESTORE_RISK", "ACTIVE", ev))
                    remediations.append(step("REMEDIATION", system, rid, "BLOCK_RESTORE", "BLOCKED"))
                    verifications.append(step("VERIFICATION", system, rid, "VERIFY_RESTORE_BLOCKED", "BLOCKED"))
            continue
        if cat == "ACCOUNT_TOMBSTONE" or action == "REDACT":
            direct = any(norm(obj.get(k)) for k in (
                "email", "phone", "email_hash", "full_name", "name",
                "requester_email", "requester_phone", "requester_name",
            ))
            if cat == "SUPPORT_MESSAGE":
                message = " ".join(str(obj.get(field, "")) for field in ("message_text", "message_excerpt"))
                direct = direct or any(
                    alias in norm(message)
                    for alias in aliases
                    if alias and ("@" in alias or "+" in alias or " " in alias)
                )
            if direct:
                findings.append(step("FINDING", system, rid, "REPORT_EXPOSED_PII", "PRESENT", ev))
                remediations.append(step("REMEDIATION", system, rid, "REDACT_RECORD", "REDACTED"))
                verifications.append(step("VERIFICATION", system, rid, "VERIFY_RECORD_REDACTED", "REDACTED"))
            else:
                safe_verifications[key] = step("VERIFICATION", system, rid, "VERIFY_RECORD_REDACTED", "REDACTED", ev)
            continue
        if cat in ("ANALYTICS_PROFILE", "PRODUCT_TELEMETRY") or action == "ANONYMIZE":
            direct = any(norm(obj.get(k)) for k in ("email", "phone", "email_hash", "full_name", "name", "customer_reference"))
            if observed_state in {"IDENTIFIABLE", "ATTRIBUTABLE", "PRESENT"}:
                direct = True
            elif observed_state in {"ANONYMIZED", "ANONYMISED", "UNLINKED"}:
                direct = False
            if m.get("kind") == "log" and ("rows=1" in text or "email_opt_in=true" in text):
                direct = True
            if direct:
                findings.append(step("FINDING", system, rid, "REPORT_EXPOSED_PII", "PRESENT", ev))
                remediations.append(step("REMEDIATION", system, rid, "ANONYMIZE_RECORD", "ANONYMIZED"))
                verifications.append(step("VERIFICATION", system, rid, "VERIFY_RECORD_ANONYMIZED", "ANONYMIZED"))
            else:
                safe_verifications[key] = step("VERIFICATION", system, rid, "VERIFY_RECORD_ANONYMIZED", "ANONYMIZED", ev)
            continue
        if cat == "SUPPORT_MESSAGE":
            # Shared-context conversations are retained; redact only when direct
            # identifiers are still present in the record itself.
            message = " ".join(str(obj.get(field, "")) for field in ("message_text", "message_excerpt"))
            direct_exposed = any(norm(obj.get(field)) for field in (
                "requester_email", "requester_name", "requester_phone", "email", "phone"
            ))
            if observed_state in {"IDENTIFIABLE", "EXPOSED", "PRESENT"}:
                direct_exposed = True
            elif observed_state in {"REDACTED", "ANONYMIZED", "ANONYMISED"}:
                direct_exposed = False
            direct_exposed = direct_exposed or any(
                alias in norm(message)
                for alias in aliases
                if alias and ("@" in alias or "+" in alias or " " in alias)
            )
            if direct_exposed:
                findings.append(step("FINDING", system, rid, "REPORT_EXPOSED_PII", "PRESENT", ev))
                remediations.append(step("REMEDIATION", system, rid, "REDACT_RECORD", "REDACTED"))
                verifications.append(step("VERIFICATION", system, rid, "VERIFY_RECORD_REDACTED", "REDACTED"))
            else:
                safe_verifications[key] = step("VERIFICATION", system, rid, "VERIFY_RECORD_REDACTED", "REDACTED", ev)
            continue
        if cat in ("USER_PROFILE", "SECONDARY_IDENTIFIER", "SEARCH_INDEX_ENTRY", "CACHE_ENTRY",
                   "USER_EXPORT", "MARKETING_PROFILE", "SUPPORT_ATTACHMENT", "SUPPORT_MESSAGE", "EMAIL_DELIVERY_LOG"):
            findings.append(step("FINDING", system, rid, "REPORT_REMAINING_RECORD", "PRESENT", ev))
            if cat == "EMAIL_DELIVERY_LOG":
                op, state, vop, vs = "REDACT_RECORD", "REDACTED", "VERIFY_RECORD_REDACTED", "REDACTED"
                findings[-1]["operation"] = "REPORT_EXPOSED_PII"
            elif cat in ("ANALYTICS_PROFILE", "PRODUCT_TELEMETRY"):
                op, state, vop, vs = "ANONYMIZE_RECORD", "ANONYMIZED", "VERIFY_RECORD_ANONYMIZED", "ANONYMIZED"
            else:
                op, state, vop, vs = "DELETE_RECORD", "ABSENT", "VERIFY_RECORD_ABSENT", "ABSENT"
            remediations.append(step("REMEDIATION", system, rid, op, state))
            verifications.append(step("VERIFICATION", system, rid, vop, vs))
            continue

    # Find an account resource explicitly associated with this subject if possible.
    account_resources = [m for m in matches if m["system_id"] == "account_service" and m["resource_id"] != "unresolved_resource"]
    # If there is no violation but there is no evidence of an absent account, do not claim COMPLETE.
    if not findings:
        # Only evidence-backed verification steps can be emitted for COMPLETE.
        for v in safe_verifications.values():
            verifications.append(v)
        # Do not manufacture a remaining-record finding when the evidence only
        # establishes compliant resource states. If all discovered relevant
        # resources have evidence-backed compliant checks and no violation was
        # found, report those checks as the basis for completion.
        if verifications:
            result = verifications
            status = "COMPLETE"
        else:
            if account_resources:
                account = account_resources[-1]
                rid = account["resource_id"]
                findings.append(step("FINDING", "account_service", rid,
                                     "REPORT_REMAINING_RECORD", "PRESENT",
                                     account["evidence_id"]))
                remediations.append(step("REMEDIATION", "account_service", rid,
                                         "DELETE_RECORD", "ABSENT"))
                verifications.append(step("VERIFICATION", "account_service", rid,
                                          "VERIFY_RECORD_ABSENT", "ABSENT"))
            status = "INCOMPLETE"
            result = findings + remediations + verifications
    else:
        # A non-complete case needs post-remediation verification steps. Convert
        # every safe current-state check to a future check with no evidence ID.
        verifications = [
            step("VERIFICATION", v["system_id"], v["resource_id"], v["operation"], v["state"])
            for v in safe_verifications.values()
        ] + verifications
        # Always include account absence/cleanup if a matched account resource is available.
        account_ids = sorted({m["resource_id"] for m in account_resources})
        for rid in account_ids:
            if not any(s["resource_id"] == rid and s["operation"] == "DELETE_RECORD" for s in remediations):
                # A resource found in an account profile is a deletion obligation.
                findings.append(step("FINDING", "account_service", rid, "REPORT_REMAINING_RECORD", "PRESENT",
                                     next(m["evidence_id"] for m in account_resources if m["resource_id"] == rid)))
                remediations.append(step("REMEDIATION", "account_service", rid, "DELETE_RECORD", "ABSENT"))
                verifications.append(step("VERIFICATION", "account_service", rid, "VERIFY_RECORD_ABSENT", "ABSENT"))
        # Retained security audit records found in the evidence are part of the verification plan.
        for v in safe_verifications.values():
            if (v["system_id"], v["resource_id"], v["operation"]) not in {
                (s["system_id"], s["resource_id"], s["operation"]) for s in verifications
            }:
                verifications.append(step("VERIFICATION", v["system_id"], v["resource_id"],
                                          v["operation"], v["state"]))
            unique_verifications = {}
            for verification in verifications:
                unique_verifications[(verification["system_id"], verification["resource_id"],
                          verification["operation"])] = verification
            verifications = list(unique_verifications.values())
        status = "INCOMPLETE"
        result = findings + remediations + verifications

    # Stable operation order within phase as specified in the challenge.
    phase_order = {"FINDING": 0, "REMEDIATION": 1, "VERIFICATION": 2}
    op_order = {
        "REPORT_REMAINING_RECORD": 0, "REPORT_EXPOSED_PII": 1, "REPORT_ACTIVE_DATA_FLOW": 2, "REPORT_RESTORE_RISK": 3,
        "DISABLE_DATA_FLOW": 0, "BLOCK_RESTORE": 1, "DELETE_RECORD": 2, "REDACT_RECORD": 3, "ANONYMIZE_RECORD": 4,
        "VERIFY_RECORD_ABSENT": 0, "VERIFY_RECORD_PRESENT": 1, "VERIFY_RECORD_REDACTED": 2,
        "VERIFY_RECORD_ANONYMIZED": 3, "VERIFY_DATA_FLOW_DISABLED": 4, "VERIFY_RESTORE_BLOCKED": 5,
    }
    result.sort(key=lambda s: (phase_order.get(s["phase"], 9), op_order.get(s["operation"], 9),
                               s["system_id"], s["resource_id"]))
    for i, s in enumerate(result, 1):
        s["step_no"] = i
    # Exact required field set/order (JSON key order is not graded, but keep it consistent).
    result = [{"step_no": s["step_no"], "phase": s["phase"], "system_id": s["system_id"],
               "resource_id": s["resource_id"], "operation": s["operation"], "state": s["state"],
               "evidence_id": s.get("evidence_id", "")} for s in result]
    return status, result

def main() -> None:
    required = [
        DATASET / "deletion_requests.csv", DATASET / "sample_deletion_requests.csv",
        DATASET / "deletion_rules.csv",
        DATASET / "user_identities.csv", DATASET / "user_audit_log.csv",
        DATASET / "system_activity.csv", DATASET / "evidence_files.csv",
    ]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        raise FileNotFoundError("Missing required input file(s): " + ", ".join(missing))
    request_file = DATASET / ("sample_deletion_requests.csv" if "--sample" in sys.argv else "deletion_requests.csv")
    requests = load_csv(request_file)
    identities = load_csv(DATASET / "user_identities.csv")
    history = load_csv(DATASET / "user_audit_log.csv")
    activities = load_csv(DATASET / "system_activity.csv")
    manifest = load_csv(DATASET / "evidence_files.csv")
    rules = load_deletion_rules(DATASET / "deletion_rules.csv")
    requests.sort(key=lambda r: r["case_id"])
    with OUTPUT.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["case_id", "deletion_status", "steps_json"], lineterminator="\n")
        writer.writeheader()
        for req in requests:
            status, steps = decide_case(req, identities, history, manifest, activities, rules)
            writer.writerow({"case_id": req["case_id"], "deletion_status": status,
                             "steps_json": json.dumps(steps, ensure_ascii=False, separators=(",", ":"))})
    # Structural validation.
    produced = load_csv(OUTPUT)
    expected_ids = [r["case_id"] for r in requests]
    assert [r["case_id"] for r in produced] == expected_ids, "Output case IDs/order do not match input"
    assert len({r["case_id"] for r in produced}) == len(expected_ids), "Duplicate case IDs in output"
    allowed_status = {"COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"}
    valid_operation_states = {
        ("FINDING", "REPORT_REMAINING_RECORD", "PRESENT"),
        ("FINDING", "REPORT_EXPOSED_PII", "PRESENT"),
        ("FINDING", "REPORT_ACTIVE_DATA_FLOW", "ACTIVE"),
        ("FINDING", "REPORT_RESTORE_RISK", "ACTIVE"),
        ("REMEDIATION", "DISABLE_DATA_FLOW", "DISABLED"),
        ("REMEDIATION", "BLOCK_RESTORE", "BLOCKED"),
        ("REMEDIATION", "DELETE_RECORD", "ABSENT"),
        ("REMEDIATION", "REDACT_RECORD", "REDACTED"),
        ("REMEDIATION", "ANONYMIZE_RECORD", "ANONYMIZED"),
        ("VERIFICATION", "VERIFY_RECORD_ABSENT", "ABSENT"),
        ("VERIFICATION", "VERIFY_RECORD_PRESENT", "PRESENT"),
        ("VERIFICATION", "VERIFY_RECORD_REDACTED", "REDACTED"),
        ("VERIFICATION", "VERIFY_RECORD_ANONYMIZED", "ANONYMIZED"),
        ("VERIFICATION", "VERIFY_DATA_FLOW_DISABLED", "DISABLED"),
        ("VERIFICATION", "VERIFY_RESTORE_BLOCKED", "BLOCKED"),
    }
    citation_warnings = 0
    unresolved_plans = 0
    for row in produced:
        assert row["deletion_status"] in allowed_status
        steps = json.loads(row["steps_json"])
        if row["deletion_status"] == "NOT_APPLICABLE":
            assert steps == [], f"NOT_APPLICABLE case {row['case_id']} must have no steps"
        elif not steps:
            # No evidence-linked resource was discovered. Keep the request
            # INCOMPLETE rather than fabricating a finding, resource ID, or
            # citation. The evaluation workflow reports this contract gap.
            assert row["deletion_status"] == "INCOMPLETE"
            unresolved_plans += 1
        phase_rank = {"FINDING": 0, "REMEDIATION": 1, "VERIFICATION": 2}
        assert [phase_rank[s["phase"]] for s in steps] == sorted(phase_rank[s["phase"]] for s in steps)
        for i, s in enumerate(steps, 1):
            assert s["step_no"] == i
            assert set(s) == {"step_no", "phase", "system_id", "resource_id", "operation", "state", "evidence_id"}
            assert (s["phase"], s["operation"], s["state"]) in valid_operation_states, (
                f"Invalid phase/operation/state in {row['case_id']}: "
                f"{s['phase']}/{s['operation']}/{s['state']}"
            )
            if s["phase"] == "FINDING":
                citation_warnings += not bool(s["evidence_id"])
            if row["deletion_status"] == "INCOMPLETE" and s["phase"] != "FINDING":
                assert s["evidence_id"] == "", f"Planned step for {row['case_id']} must not cite existing evidence"
            if row["deletion_status"] == "COMPLETE":
                citation_warnings += not bool(s["evidence_id"])
    print(f"Wrote {OUTPUT} with {len(produced)} rows from {request_file.name}.")
    if citation_warnings:
        print(f"WARNING: {citation_warnings} findings/completion checks lack evidence citations.")
    if unresolved_plans:
        print(f"WARNING: {unresolved_plans} INCOMPLETE requests have no evidence-backed plan.")
    print("Status counts:", {s: sum(r["deletion_status"] == s for r in produced)
                              for s in ("COMPLETE", "INCOMPLETE", "NOT_APPLICABLE")})

if __name__ == "__main__":
    main()
