# Usage Report

## Final full-dataset run

- **Implementation:** deterministic Python evidence/rule pipeline (`code/main.py`); no hosted or local generative model is invoked.
- **Model provider/name:** None / N/A (no model inference).
- **Model calls:** 0.
- **Input tokens:** 0.
- **Output tokens:** 0.
- **Total tokens:** 0.
- **Average tokens per request:** 0 across 518 requests; token usage is not applicable because there were no model calls.
- **Estimated model cost:** $0.00 total and $0.00 per request; no model provider was billed.
- **Per-model totals:** None.

The values above describe model usage only. They exclude local CPU time, memory, and any local OCR execution. PDF and screenshot OCR are optional local dependencies; neither makes a model/API call. A production submission that requires an AI model should replace this report with measured provider usage and token/cost accounting from that actual run.
