"""Run the production pipeline on the public sample and compare answers."""
from __future__ import annotations

import csv
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output.csv"
SAMPLE_EXPECTED = ROOT / "dataset" / "sample_output.csv"


def run_custom_cases() -> None:
    spec = importlib.util.spec_from_file_location("audit_pipeline", ROOT / "code" / "main.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("Could not load the production pipeline")
    pipeline = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pipeline)

    cases = {
        "marketing_opt_out_is_not_deletion": lambda: not pipeline.email_is_deletion_intent(
            "Please remove me from marketing lists only; keep my account."
        ),
        "identifier_matching_is_token_exact": lambda: (
            pipeline.contains_identifier("subject=user_43", {"user_43"})
            and not pipeline.contains_identifier("subject=user_430", {"user_43"})
        ),
        "historical_alias_respects_audit_cutoff": lambda: _historical_alias_cutoff_case(pipeline),
    }
    failed = [name for name, check in cases.items() if not check()]
    if failed:
        raise AssertionError("Custom regression cases failed: " + ", ".join(failed))
    print(f"PASS: {len(cases)} custom regression cases")


def _historical_alias_cutoff_case(pipeline: object) -> bool:
    identity = [{"user_id": "user_900", "email": "current@example.test", "name": "Test User"}]
    before_cutoff = [{
        "user_id": "user_900", "field_name": "email", "old_value": "old@example.test",
        "new_value": "current@example.test", "event_time": "2026-01-01T00:00:00Z",
    }]
    after_cutoff = [{
        "user_id": "user_900", "field_name": "email", "old_value": "old@example.test",
        "new_value": "current@example.test", "event_time": "2026-03-01T00:00:00Z",
    }]
    cutoff = pipeline.parse_time("2026-02-01T00:00:00Z")
    request = {"email": "old@example.test"}
    before_users, _ = pipeline.resolve_users(request, identity, before_cutoff, cutoff)
    after_users, _ = pipeline.resolve_users(request, identity, after_cutoff, cutoff)
    return len(before_users) == 1 and not after_users


def main() -> None:
    run_custom_cases()
    before = OUTPUT.read_bytes() if OUTPUT.exists() else None
    try:
        subprocess.run(
            [sys.executable, str(ROOT / "code" / "main.py"), "--sample"],
            cwd=ROOT,
            check=True,
        )
        with OUTPUT.open("r", encoding="utf-8-sig", newline="") as f:
            actual_rows = list(csv.DictReader(f))
        with SAMPLE_EXPECTED.open("r", encoding="utf-8-sig", newline="") as f:
            expected_rows = list(csv.DictReader(f))

        assert len(actual_rows) == len(expected_rows) == 32, (
            f"Expected 32 sample rows; got {len(actual_rows)} actual and {len(expected_rows)} expected"
        )
        actual = {row["case_id"]: row for row in actual_rows}
        expected = {row["case_id"]: row for row in expected_rows}
        assert set(actual) == set(expected), "Generated sample case IDs differ from the reference"

        failures: list[str] = []
        status_correct = 0
        exact_rows = 0
        exact_sequences = 0
        total_expected_steps = 0
        exact_steps = 0
        fields_correct = 0
        fields_total = 0
        for case_id in sorted(expected):
            got = actual[case_id]
            want = expected[case_id]
            status_matches = got["deletion_status"] == want["deletion_status"]
            status_correct += status_matches
            if not status_matches:
                failures.append(
                    f"{case_id}: status {got['deletion_status']} != {want['deletion_status']}"
                )
            try:
                actual_steps = json.loads(got["steps_json"])
                expected_steps = json.loads(want["steps_json"])
            except json.JSONDecodeError as exc:
                failures.append(f"{case_id}: invalid steps_json ({exc})")
                continue
            sequence_matches = actual_steps == expected_steps
            exact_sequences += sequence_matches
            exact_rows += status_matches and sequence_matches
            total_expected_steps += len(expected_steps)
            for index, expected_step in enumerate(expected_steps):
                actual_step = actual_steps[index] if index < len(actual_steps) else {}
                step_matches = actual_step == expected_step
                exact_steps += step_matches
                fields_total += len(expected_step)
                fields_correct += sum(
                    actual_step.get(field) == value
                    for field, value in expected_step.items()
                )
            if not sequence_matches:
                failures.append(f"{case_id}: step arrays differ")

        print(
            "Public sample metrics: "
            f"status={status_correct}/{len(expected_rows)}, "
            f"exact_rows={exact_rows}/{len(expected_rows)}, "
            f"exact_sequences={exact_sequences}/{len(expected_rows)}, "
            f"exact_steps={exact_steps}/{total_expected_steps}, "
            f"field_values={fields_correct}/{fields_total}"
        )
        if failures:
            raise AssertionError(
                f"Sample output mismatches ({len(failures)}):\n" + "\n".join(failures)
            )
        print(f"PASS: all {len(expected_rows)} sample rows match sample_output.csv exactly")
    finally:
        if before is None:
            OUTPUT.unlink(missing_ok=True)
        else:
            OUTPUT.write_bytes(before)


if __name__ == "__main__":
    main()
